"""
Queue System Package - Distributed crawling infrastructure
"""
# This file makes 'queue_system' a Python package.
# Removed explicit imports as they are not strictly necessary for package definition.
